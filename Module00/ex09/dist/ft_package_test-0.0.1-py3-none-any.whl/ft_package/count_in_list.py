def count_in_list(lst: list, target):
    """This counts the number of the time the target appears
        in the list and returns the number"""

    return lst.count(target)
