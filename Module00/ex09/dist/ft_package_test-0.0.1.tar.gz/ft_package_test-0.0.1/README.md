# ft_package

**ft_package** is a small sample package created for the Python Piscine for Data Science. It provides a single helper function, **count_in_list**, which counts how many times a given value appears in a list.


### Build
To build the package:
```python3 -m build  ```

### Display the package list
To display the installed package list:
```pip list```

### Installation
Install the package from one of the built distribution files:
```pip install ./dist/ft_package-0.0.1.tar.gz```
or
```pip install ./dist/ft_package-0.0.1-py3-none-any.whl```

### Display the package's characteristics
To display the pakage's characteristics:
```pip show -v ft_package```